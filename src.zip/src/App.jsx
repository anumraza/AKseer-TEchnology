import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Leaf, Zap, Wind, DollarSign, BatteryCharging, TrendingUp, Home, Factory, Mountain } from 'lucide-react';

// --- Utility Components ---

// Simple Card component for features
const FeatureCard = ({ icon: Icon, title, description }) => (
  <div className="flex flex-col items-start p-6 bg-white bg-opacity-95 backdrop-blur-sm rounded-xl shadow-lg hover:shadow-2xl transition duration-300 transform hover:-translate-y-1 border border-gray-100">
    <div className="p-3 mb-4 bg-emerald-500 rounded-full text-white shadow-md">
      <Icon size={24} />
    </div>
    <h3 className="text-xl font-bold text-gray-800 mb-2">{title}</h3>
    <p className="text-gray-600 text-sm">{description}</p>
  </div>
);

// Animated Scroll Indicator for the Hero section
const ScrollDownIndicator = () => (
  <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 flex flex-col items-center">
    <p className="text-white text-sm mb-2 font-medium">Scroll Down</p>
    <div className="w-6 h-10 border-2 border-white rounded-full p-0.5">
      <div className="w-full h-1.5 bg-white rounded-full animate-scroll-bounce"></div>
    </div>
  </div>
);

// --- Main Application Components ---

const Header = () => {
  // Use state to manage the sticky header and mobile menu
  const [isSticky, setIsSticky] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsSticky(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Product', href: '#product' },
    { label: 'Benefits', href: '#benefits' },
    { label: 'Applications', href: '#applications' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <header className={`fixed w-full z-50 transition-all duration-300 ${isSticky ? 'bg-white shadow-lg py-3' : 'bg-transparent py-5'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
        {/* Logo */}
        <div className="flex items-center space-x-2">
          {/* Logo Placeholder - use your logo here */}
          <div className={`w-8 h-8 rounded-full transition-colors duration-300 ${isSticky ? 'bg-emerald-500' : 'bg-white'}`}>
            <Wind className={`text-white transition-colors duration-300 ${isSticky ? 'text-white p-1' : 'text-emerald-500 p-1'}`} />
          </div>
          <span className={`text-2xl font-extrabold transition-colors duration-300 ${isSticky ? 'text-gray-800' : 'text-white'}`}>Akseer Pankh</span>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex space-x-8">
          {navItems.map((item) => (
            <a key={item.label} href={item.href} className={`text-base font-medium transition-colors duration-300 ${isSticky ? 'text-gray-600 hover:text-emerald-600' : 'text-white hover:text-emerald-300'}`}>
              {item.label}
            </a>
          ))}
        </nav>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden p-2 rounded-md focus:outline-none focus:ring-2 focus:ring-emerald-500"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          <svg className={`w-6 h-6 transition-colors duration-300 ${isSticky ? 'text-gray-800' : 'text-white'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={isMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"}></path>
          </svg>
        </button>
      </div>

      {/* Mobile Navigation Panel */}
      {isMenuOpen && (
        <div className={`md:hidden bg-white shadow-xl py-4 transition-all duration-300 ${isSticky ? 'mt-0' : 'mt-2'}`}>
          <div className="px-2 pt-2 pb-3 space-y-1">
            {navItems.map((item) => (
              <a key={item.label} href={item.href} onClick={() => setIsMenuOpen(false)} className="block px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-emerald-600 hover:bg-gray-50">
                {item.label}
              </a>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};

const HeroSection = () => (
  <section className="relative h-screen bg-gray-900 overflow-hidden" id="hero">
    {/* Background Image/Video Placeholder */}
    <div className="absolute inset-0 bg-cover bg-center opacity-70"
      style={{
        backgroundImage: 'url("IMAGE_SOURCE_HERO_BACKGROUND")',
        backgroundBlendMode: 'multiply',
        backgroundColor: '#059669', // Emerald background blend for a strong visual look
      }}
    >
      {/* Fallback/Overlay */}
      <div className="absolute inset-0 bg-emerald-700 mix-blend-multiply opacity-50"></div>
    </div>

    <div className="relative z-10 flex items-center justify-center h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
      <div className="max-w-4xl">
        <h1 className="text-5xl sm:text-6xl lg:text-7xl font-extrabold text-white leading-tight mb-4 animate-fadeInUp">
          <span className="block">Pankh: Wind Turbine for You,</span>
          <span className="text-emerald-300 block">for Your Energy Needs</span>
        </h1>
        <p className="text-xl sm:text-2xl text-emerald-100 font-light mb-10 animate-fadeInUp delay-200">
          Akseer Technology's compact, cost-effective, and powerful utility wind solution.
        </p>
        <a href="#product" className="inline-block px-10 py-4 text-lg font-semibold text-white bg-emerald-600 rounded-full shadow-lg hover:bg-emerald-700 transition duration-300 transform hover:scale-105 animate-fadeInUp delay-400">
          Discover the Power
        </a>
      </div>
    </div>
    <ScrollDownIndicator />
  </section>
);

const FeaturesSection = () => {
  const features = [
    {
      icon: DollarSign,
      title: "Cost-Effective",
      description: "Wind power costs just 40% as much as solar power (American Wind Energy Association). The unit cost is suitable for the average individual.",
    },
    {
      icon: Zap,
      title: "High Daily Capacity",
      description: "Achieve a daily capacity of around 100 kWh, significantly reducing or eliminating electricity usage from utility providers.",
    },
    {
      icon: Wind,
      title: "Low Cut-In Speed",
      description: "Operates effectively at very low wind speeds, allowing it to continuously generate power, unlike existing small turbines.",
    },
    {
      icon: Leaf,
      title: "Sustainable & Clean",
      description: "Harnessing an abundant source of clean energy with zero atmospheric emissions. Contribute to a greener future.",
    },
    {
      icon: BatteryCharging,
      title: "Flexible Power Modes",
      description: "Can be used for both on-grid (utility power) and off-grid (battery) systems, offering maximum energy resilience.",
    },
    {
      icon: TrendingUp,
      title: "Hybrid Solution Ready",
      description: "Easily combined with solar panels for increased power output and an improved Return on Investment (RoI).",
    },
  ];

  return (
    <section id="benefits" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-extrabold text-gray-900 mb-4">The Pankh Advantage</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">Superior engineering and strategic design for maximum power generation and efficiency.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <FeatureCard
              key={index}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
}; // Fixed: Removed the extraneous closing parenthesis here

const ProductDetailsSection = () => (
  <section id="product" className="py-20 bg-white">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="lg:grid lg:grid-cols-2 lg:gap-16 items-center">
        {/* Image/Visual Area */}
        <div className="mb-12 lg:mb-0 relative">
          {/* Product Image Placeholder - use an image of the turbine */}
          <div className="w-full h-80 sm:h-96 lg:h-[500px] bg-gray-200 rounded-2xl shadow-2xl overflow-hidden">
            <img src="IMAGE_SOURCE_PRODUCT_ON_ROOFTOP" alt="Akseer Pankh Wind Turbine installed on a rooftop" className="w-full h-full object-cover" />
          </div>
          <div className="absolute -bottom-6 -right-6 p-4 bg-emerald-500 rounded-xl text-white shadow-xl">
            <p className="text-sm font-semibold">Tested in UAE after 14 years of R&D</p>
          </div>
        </div>

        {/* Text Content */}
        <div>
          <h2 className="text-4xl font-extrabold text-gray-900 mb-6">Akseer Pankh: Engineered for Performance</h2>
          <p className="text-gray-600 text-lg mb-8">
            The Pankh turbine is the result of 14 years of dedicated research and development, designed specifically to outperform existing small wind turbines in its category.
          </p>

          <ul className="space-y-4 text-gray-700">
            <li className="flex items-start">
              <span className="flex-shrink-0 mr-3 mt-1 text-emerald-500"><svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 14.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path></svg></span>
              <div>
                <strong className="font-semibold text-gray-800">Lightweight & Durable:</strong> Fiberglass composite blades developed after extensive research ensure long life and reduced weight.
              </div>
            </li>
            <li className="flex items-start">
              <span className="flex-shrink-0 mr-3 mt-1 text-emerald-500"><svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 14.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path></svg></span>
              <div>
                <strong className="font-semibold text-gray-800">Compact Footprint:</strong> Requires a small plot plan, approximately 1/10th the size of solar panels. Dust and sand do not reduce its efficiency.
              </div>
            </li>
            <li className="flex items-start">
              <span className="flex-shrink-0 mr-3 mt-1 text-emerald-500"><svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 14.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path></svg></span>
              <div>
                <strong className="font-semibold text-gray-800">Superior Output:</strong> Produces better power output compared to other wind turbines in this size category, designed for both rural and urban use.
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </section>
);

const ApplicationSection = () => {
  const applications = [
    { icon: Home, title: "Homes & Backyards", description: "Easily mounted on rooftops or small farms, perfect for residential use to dramatically reduce utility bills." },
    { icon: Factory, title: "Buildings & Commercial", description: "Scaleable for commercial installations and buildings seeking reliable, supplementary or primary power generation." },
    { icon: Mountain, title: "Farms & Open Landscape", description: "Ideal for remote locations, farms, and open landscapes where wind resources are abundant and grid access may be limited." },
  ];

  return (
    <section id="applications" className="py-20 bg-emerald-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-4xl font-extrabold text-gray-900 mb-4">Where Pankh Works for You</h2>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-16">Designed for versatility—from the urban rooftop to the open field.</p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {applications.map((app, index) => (
            <div key={index} className="p-8 bg-white rounded-xl shadow-xl hover:shadow-2xl transition duration-300 transform hover:-translate-y-1">
              <div className="w-16 h-16 mx-auto mb-4 flex items-center justify-center bg-emerald-500 bg-opacity-10 rounded-full">
                <app.icon size={32} className="text-emerald-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-800 mb-3">{app.title}</h3>
              <p className="text-gray-600 text-sm">{app.description}</p>
            </div>
          ))}
        </div>

        {/* Secondary image of turbine in a landscape */}
        <div className="mt-16 w-full h-80 bg-gray-300 rounded-xl overflow-hidden shadow-inner">
          <img src="IMAGE_SOURCE_PRODUCT_IN_FIELD" alt="Akseer Pankh Wind Turbine in an open landscape" className="w-full h-full object-cover object-center" />
        </div>
      </div>
    </section>
  );
};

const ContactSection = () => (
  <section id="contact" className="py-20 bg-gray-900 text-center">
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
      <h2 className="text-4xl font-extrabold text-white mb-4">Ready to Harness Your Energy?</h2>
      <p className="text-xl text-emerald-200 font-light mb-10">
        Stop relying on utility providers. Invest in sustainable, efficient power today.
      </p>
      <a href="mailto:contact@akseer.com" className="inline-block px-12 py-5 text-xl font-bold text-gray-900 bg-emerald-400 rounded-full shadow-2xl hover:bg-emerald-300 transition duration-300 transform hover:scale-105">
        Get a Free Consultation
      </a>
      <p className="mt-6 text-sm text-gray-400">Tested and Made in UAE.</p>
    </div>
  </section>
);

const Footer = () => (
  <footer className="bg-gray-800 text-white py-8">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center sm:flex sm:justify-between sm:items-center">
      <p className="text-sm">&copy; {new Date().getFullYear()} Akseer Technology. All rights reserved.</p>
      <div className="flex justify-center space-x-4 mt-4 sm:mt-0">
        <a href="#product" className="text-gray-400 hover:text-emerald-400 text-sm">Product</a>
        <a href="#benefits" className="text-gray-400 hover:text-emerald-400 text-sm">Benefits</a>
        <a href="#contact" className="text-gray-400 hover:text-emerald-400 text-sm">Contact</a>
      </div>
    </div>
  </footer>
);

// --- Main App Component ---

export default function App() {
  return (
    <div className="min-h-screen bg-white font-['Inter']">
      {/* Tailwind configuration for custom animation */}
      <style>{`
        @keyframes scroll-bounce {
          0%, 100% { transform: translateY(0); opacity: 1; }
          50% { transform: translateY(6px); opacity: 0.5; }
        }
        .animate-scroll-bounce {
          animation: scroll-bounce 1.5s infinite;
        }

        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeInUp {
          animation: fadeInUp 0.6s ease-out both;
        }
        .delay-200 { animation-delay: 0.2s; }
        .delay-400 { animation-delay: 0.4s; }
      `}</style>

      <Header />
      <main>
        <HeroSection />
        <FeaturesSection />
        <ProductDetailsSection />
        <ApplicationSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}
